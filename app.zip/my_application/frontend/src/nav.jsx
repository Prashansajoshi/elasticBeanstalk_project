import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css'


const Nav = () => {
  return(
    <div className="d-flex justify-content-center py-2 shadow-sm fs-2 fw-bold" >
      Academic Result For 2024
    </div>
  )
}

export default Nav